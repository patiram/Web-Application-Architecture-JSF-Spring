/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mum.edu;



import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

/**
 *
 * @author 984928
 */
@Named("user")
@SessionScoped
public class demo1 implements Serializable {
   private String name;
   private String password;
   private String greeting;
   
   public String getName() { return name; }  
   public void setName(String newValue) { name = newValue; }
 
   public String getPassword() { return password; }
   public void setPassword(String newValue) { password = newValue; }  
   
   public String getGreeting(){return greeting;}
   public void setGreeting(String newGreeting){greeting= newGreeting;}
 
    // action="#{user.onLogin}"
    // As we shall see, the return value indicates what the next page will be
    public String onLogin()
    {
        if(name.equals("patiram")&&password.equals("abc")){
            return "loginSuccess";
        }else{
            return "index";
        }
    }
}
