/**
 * Question has a question and associated (correct) answer
 */
package mum.edu.quiz.model;

import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

/**
 *
 * @author levi
 */
@Named
@SessionScoped
public class Problem implements Serializable{
    private String question;
    private String answer;
    private String hint;
    
    public Problem(String question, String answer, String hint) {
        this.question = question;
        this.answer = answer;
        this.hint = hint;
    }

    public String getQuestion() {
        return question;
    }

    public String getAnswer() {
        return answer;
    }

    public String getHint() {
        return hint;
    }

    public void setHint(String hint) {
        this.hint = hint;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

}
